package com.uni.lista1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lista1Application {

	public static void main(String[] args) {
		SpringApplication.run(Lista1Application.class, args);
	}

}
