package pl.opole.uni.lista3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lista3Application {

	public static void main(String[] args) {
		SpringApplication.run(Lista3Application.class, args);
	}

}
