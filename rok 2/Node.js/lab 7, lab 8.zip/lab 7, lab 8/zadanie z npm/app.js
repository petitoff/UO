var us = require("underscore.string");
console.log(us.capitalize("testowy string"));
